#include "book.h"
#include"library.h"
#include <gtest/gtest.h>
namespace 
{

class LibraryTest : public ::testing::Test 
{

    protected:
    void SetUp() { 
{
        libr.addBook( 11,"c++","sai","jubliant",600,200 );
        libr.addBook( 12,"data science","pilse","downtime",300,500 );
        libr.addBook( 13,"HTML","Micky","peter",800,220);
    }
    void TearDown() {
    }
    Library libr;
};
TEST_F(LibraryTest,CountAccounts) 
{
  EXPECT_EQ(3,libr.countAll());
}

TEST_F(LibraryTest,AddBook) 
{
  libr.addBook( 14,"Lab book","Naveen","Sai",700,200 );
  EXPECT_EQ(4,libr.countAll());
  Book *ptr=libr.findBookById( 14 );
  EXPECT_NE(nullptr, ptr);
  EXPECT_EQ(14, ptr->getId());
  EXPECT_EQ(600, ptr->getPrice());
}
TEST_F(LibraryTest,RemoveBook) 
{
  libr.removeBook( 12 );
  EXPECT_EQ(2,libr.countAll());
  Book *ptr=libr.findBookById( 12);
  EXPECT_EQ(nullptr, ptr);
}
}


