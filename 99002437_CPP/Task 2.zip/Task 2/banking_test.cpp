#include "account.h"
#include "banking.h"
#include <gtest/gtest.h>
namespace {

class BankingTest : public ::testing::Test {

protected:
  void SetUp() { 
    accounts.addAccount(11, "Sai",45.23,"7745055345");
    accounts.addAccount(12, "sams",33.23,"5674589953");
    accounts.addAccount(13, "hanna",67.55,"8845667549");
    accounts.addAccount(14, "Sofy",46.43,"2356132132");
  }
 
};

TEST_F(BankingTest, AddAccountTest) {
  accounts.addAccount(15, "James", "9845012350", 100);
  EXPECT_NE(NULL, accounts.findCustomerById(15));
  EXPECT_EQ(105, accounts.getCustomerId());
}
TEST_F(BankingTest, RemoveAccountTest) {
  accounts.removeAccount(15);
  EXPECT_EQ(NULL, accounts.findCustomerById(15));
  EXPECT_EQ(NULL, accounts.getCustomerId());
}

TEST_F(BankingTest, FindByNameTest) 
{
  Account *ptr = accounts.findCustomerByName("Sahana");
  EXPECT_STREQ("Sahana", ptr->getName().c_str());
  EXPECT_EQ(104, ptr->getCustomerId());
}

} 
