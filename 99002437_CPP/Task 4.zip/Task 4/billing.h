#include <iostream>
#include "postpaid.h"
#include "prepaid.h"
#include "customer.h"
#include <vector>
#include <list>
class Bill {
    std::list<Customer> customers; 
    std::list<PrepaidCustomer> prepaid;
    std::list<PostpaidCustomer> postpaid;
public: 
void addCustomer(int id,std::string name,std::string phoneno,double bal) {
    
    customers.push_back(Customer(id,name,phoneno,bal));
}
void removeCustomerById(int id) {
    std::list<Customer>::iterator iter;
    for(iter=customers.begin();iter!=customers.end();++iter)
    {
        if(iter->getCustomerId()==id)
        break;
    }
    if(iter!=customers.end())
    customers.erase(iter);

}
void displayAll()
{
   std::list<Customer>::iterator iter;
    for(iter=customers.begin();iter!=customers.end();++iter)
    { iter->display();} 
}
Customer* findCustomerById(int id) {
    std::list<Customer>::iterator iter;
    for(iter=customers.begin();iter!=customers.end();++iter)
    {
        if(iter->getCustomerId()==id)
        return &(*iter);
    }
    return nullptr;
}
Customer* findCustomerByName(std::string name) {
    std::list<Customer>::iterator iter;
    for(iter=customers.begin();iter!=customers.end();++iter)
    {
        if(iter->getCustomerName()==name)
        return &(*iter);
    }
    return nullptr;
}
double findAverageBalForPre()
{ double avg=0;
std::list<PrepaidCustomer>::iterator iter;
    for(iter=prepaid.begin();iter!=prepaid.end();++iter)
    {
        avg=avg+iter->getBalance();
    }
return avg/prepaid.size();

}
PostpaidCustomer* findMaxBalForPost()
{  
   std::list<PostpaidCustomer>::iterator iter;
   iter=postpaid.begin();
   double maxbal=iter->getBalance();
   std::list<PostpaidCustomer>::iterator maxiter=iter;
   ++iter;
    for(;iter!=postpaid.end();++iter)
    { 
        if(iter->getBalance()>maxbal)
        {
            maxbal=iter->getBalance();
            maxiter=iter;
        }
    }
return &(*maxiter);
}
PrepaidCustomer* findMinBalForPre()
{  
   std::list<PrepaidCustomer>::iterator iter;
   iter=prepaid.begin();
   double minbal=iter->getBalance();
   std::list<PrepaidCustomer>::iterator miniter=iter;
   ++iter;
    for(;iter!=prepaid.end();++iter)
    { 
        if(iter->getBalance()<minbal)
        {
            minbal=iter->getBalance();
            miniter=iter;
        }
    }
return &(*miniter);
}
int CountAboveLimitPre()
{int count=0;
    std::list<PrepaidCustomer>::iterator iter;
    for(iter=prepaid.begin();iter!=prepaid.end();++iter)
    {
        if(iter->getBalance()>50.0)
        ++count;
    }
    return count;
}

int CountRangePost()
{int count=0;
    std::list<PostpaidCustomer>::iterator iter;
    for(iter=postpaid.begin();iter!=postpaid.end();++iter)
    {
        if(iter->getBalance()>20.00 && iter->getBalance()<60.00)
        ++count;
    }
    return count;
}
};