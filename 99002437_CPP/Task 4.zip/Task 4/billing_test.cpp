#include "billing.h"
#include "customer.h"
#include "postpaid.h"
#include "prepaid.h"
#include <gtest/gtest.h>
namespace {

class BillingTest : public ::testing::Test {

protected:
  void SetUp() { 
    customers.addCustomer(11, "Sai", "9346729345", 400);
    customers.addCustomer(12, "Mukesh", "7845012346", 800);
    customers.addCustomer(13, "Rehan", "6745012347", 300);
    customers.addCustomer(14, "Senthil", "9945012348", 500);
    customers.addCustomer(15, "Lyod", "8845012349", 600);
    customers.addCustomer(16, "Terminols", "7845012340", 250);
  }
  
};

TEST_F(BillingTest, AddCustomerTest) {
  customers.addCustomer(19, "Jels", "9945012350", 100);
  EXPECT_NE(NULL, customers.findCustomerById(19));
  EXPECT_EQ(7, customers.countAll());
}
TEST_F(BillingTest, RemoveCustomerTest) {
  customers.removeCustomer(15);
  EXPECT_EQ(NULL, customers.findCustomerById(15));
  EXPECT_EQ(5, customers.countAll());
}
TEST_F(BillingTest, CountTest) {             //Just After Setup
  EXPECT_EQ(6, customers.countAll());
}
TEST_F(BillingTest, FindByIdTestTrue) {
  Customer *ptr = customers.findCustomerById(14);
  EXPECT_NE(NULL, ptr);
  EXPECT_EQ(500, ptr->getBalance());
  EXPECT_STREQ("Stallman", ptr->getName().c_str());
  EXPECT_STREQ("9845012348", ptr->getPhone().c_str());
}
TEST_F(BillingTest, FindByIdTestFalse) {
  Customer *ptr = customers.findCustomerById(1011);
  EXPECT_EQ(NULL, ptr);
}
TEST_F(BillingTest, FindByPhoneTest) {
  Customer *ptr = customers.findCustomerByPhone("6745012347");
  EXPECT_EQ(300, ptr->getBalance());
  EXPECT_STREQ("Richard", ptr->getName().c_str());
  EXPECT_EQ(13, ptr->getCustomerId());
}
TEST_F(BillingTest, AverageTest) {
  double avg = customers.findAverageBalance();
  EXPECT_EQ(475.0, avg);
}
TEST_F(BillingTest, MaxTest) {
  double maxbal = customers.findMaxBalance();
  EXPECT_EQ(800.0, maxbal);
}
TEST_F(BillingTest, CountMinBalTest) {
  int count = customers.countByMinBalance(320);
  EXPECT_EQ(4, count);
}
} // namespace

