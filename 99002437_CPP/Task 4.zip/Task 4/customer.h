#include <iostream>
class Customer {
    public:
    int m_id=0;
    std::string m_name, m_phoneno;
    double m_bal;
    Customer():m_id(0),m_name(""),m_phoneno(""),m_bal(0.0) {}
    Customer(int id,std::string name,std::string phoneno,double bal):m_id(id),m_name(name),m_phoneno(phoneno),m_bal(bal) {}
    int getCustomerId() 
    {
        return m_id;
    }
    std::string getCustomerName() {
        return m_name;
    }
    std::string getCustomerPhoneno() {
        return m_phoneno;
    }
    double getBalance() {
        return m_bal;
    }
    virtual void makeCall(int p) {
         m_bal=m_bal-p;
    }
    virtual void credit(int p) {
         m_bal=m_bal+p;
    }
    virtual void display() {
        std::cout<<"\nId: "<<m_id<<"\nName: "<<m_name<<"\nPhoneno: "<<m_phoneno<<"\nBalance: "<<m_bal<<"\n";
    }
    friend std::ostream& operator<<(std::ostream& rout,const Customer& ref)
    {
        rout<<"\nId: "<<ref.m_id<<"\nName: "<<ref.m_name<<"\nPhoneno: "<<ref.m_phoneno<<"\nBalance: "<<ref.m_bal<<"\n";
    }
};