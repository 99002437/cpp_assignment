#include <iostream>
#include "customer.h"
class PrepaidCustomer: public Customer {
    public:
    PrepaidCustomer() {}
    int getCustomerId() 
    {
        return m_id;
    }
    std::string getCustomerName() {
        return m_name;
    }
    std::string getCustomerPhoneno() {
        return m_phoneno;
    }
    double getBalance() {
        return m_bal;
    }
    void makeCall(int p) {
         m_bal=m_bal-p;
    }
    void credit(int p) {
         m_bal=m_bal+p;
    }
};
