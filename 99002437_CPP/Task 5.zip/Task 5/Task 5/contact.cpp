#include"contact.h"
#include<iostream>
#include<sstream>
#include<cstring>

using namespace std;
int contact::ID=100;


contact::contact():first_name{""},last_name{""},pri_no{""},
                    sec_no{""}{this->id= ID++;}

contact::contact(std::string fn,std::string ln, std::string pn,std::string sn){
    id= ID++;
    first_name= fn;
    last_name= ln;
    pri_no=pn;
    sec_no=sn;
}

std::string contact::get_name(){
    stringstream ss;
    ss<< first_name<< " "<<last_name;
    return(ss.str());
}
std::string contact::mob() {return{pri_no};}

std::ostream& operator<< (std::ostream& out, contact& c){
    out<<"\nID: "<<c.id<<"\nname: "<<c.last_name<<" "<<c.last_name<<"\n Ph No : "<<c.pri_no;
    return out;
}


//////////////////////////

std::vector<contact>Address::contacts;

void Address::add(contact& c){
    contacts.push_back(c);
}

void Address::del(string no){
    vector<contact>::iterator it;
    for(it= contacts.begin();it!= contacts.end();it++){
        if( strcmp(it->mob().c_str(),no.c_str())==0 ){
            contacts.erase(it);
            break;
        }
    }
}

void Address::display(){
    vector<contact>::iterator it;
    for(it= contacts.begin();it!= contacts.end();it++){
        cout<<"\nName : "<<it->get_name()<<"  No: "<<it->mob();
    }
}

std::vector<contact> Address::find_all(std::string n){
    vector<contact>::iterator it;
    vector<contact> result;
    for(it= contacts.begin();it!= contacts.end();it++){
        if(it->get_name().find(n) != string::npos){
            result.push_back(*it);
        }
    }
    return(result);
}

bool Address::update(std::string no, std::string f,std::string l,std::string al){
     vector<contact>::iterator it;
    for(it= contacts.begin();it!= contacts.end();it++){
        if (strcmp(it->mob().c_str(),no.c_str())==0){
            if((strcmp(f.c_str(),"")!=0)){
                it->set_f_name(f);
                
            }
            if((strcmp(l.c_str(),"")!=0)){
                it->set_l_name(l);
            }
            if(!strcmp(al.c_str(),"")!=0){
                it->set_secno(al);
            }
            return true;
        }
    }
    return false;
}





