#include<string>
#include<vector>
#include<ostream>
#include<iostream>

class contact{
    static int ID;
    int id;
    std::string first_name;
    std::string last_name, pri_no, sec_no;

    public:
    contact();
    contact(std::string,std::string,std::string,std::string);

    std::string get_name();
    std::string mob() ;
    int get_id(){return(id);}

    void set_f_name(std::string s){first_name=s; }
    void set_l_name(std::string s){last_name=s;}
    void set_secno(std::string s){sec_no=s;}

    friend std::ostream& operator<< (std::ostream&, contact&);   
};


class Address{
    public:
    static std::vector<contact> contacts;

    void add(contact&);
    void del(std::string);
    void display();
    std::vector<contact> find_all(std::string);
    bool update(std::string, std::string,std::string,std::string);

};