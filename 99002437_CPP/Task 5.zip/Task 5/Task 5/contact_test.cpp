#include"contact.h"
#include<gtest/gtest.h>
#include<cstring>

namespace{

    class contactlist : public ::testing::Test {
    protected:
        Address A;
        void SetUp() { 
            
            contact c1("Sai","Madhan","45321","6789");
            contact  c2("John","fernandez","9078","5467");

            A.add(c1);
            A.add(c2);

            
        }
         
       void TearDown() {
        }
    };  

    TEST_F(contactlist, getname)
    {   
        EXPECT_EQ(2,A.contacts.size() );
    }

 

}